package com.cts;

public class Booked {
public void getBooked(){
       System.out.println("Hello World");
       
}
}
