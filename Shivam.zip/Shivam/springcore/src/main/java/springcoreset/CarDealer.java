package springcoreset;

import java.util.Set;

public class CarDealer {

	private String name;
	private Set<String> modals;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Set<String> getModals() {
		return modals;
	}

	public void setModals(Set<String> modals) {
		this.modals = modals;
	}
}
