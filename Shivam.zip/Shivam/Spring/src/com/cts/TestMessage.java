package com.cts;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestMessage {

	public static void main(String[] args) {
		
		ApplicationContext context=new ClassPathXmlApplicationContext("beans.xml");
		
		Message m1=(Message)context.getBean("msgBean");
		
		System.out.println("Message 1 : "+m1.getMsg());
		
		m1.setMsg("How r u?");
		
		System.out.println("Message 1 : "+m1.getMsg());
		
		
		Message m2=(Message)context.getBean("msgBean");
		
		System.out.println("Message 2 : "+m2.getMsg());
		
		
		m2.setMsg("Good");
		
		System.out.println(m2.getMsg());
		System.out.println(m1.getMsg());
	}

}
