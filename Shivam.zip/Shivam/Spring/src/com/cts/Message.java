package com.cts;

public class Message {

	   String msg;
	  
	   

	public Message() {
		super();
	}
	


	


	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}
	   
	   
}
