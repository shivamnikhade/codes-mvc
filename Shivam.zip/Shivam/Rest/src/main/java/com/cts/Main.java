package com.cts;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

       public static void main(String[] args) {
       
              ApplicationContext con=new ClassPathXmlApplicationContext("bean.xml");
              Booked book=con.getBean("Book",Booked.class);
              book.getBooked();

       }

}
